<?php
?>
<!DOCTYPE html>
<head> 
    <meta charset="utf-8">
    <title>h_fitness register</title>
</head>
<body>
    <form action="register_controller.php" method="POST">
        <p>Name:<input type="text" name="name" placeholder="이름을 입력하세요"></p>
        <p>ID:<input type="text" name="m_id" placeholder="아이디를 생성하세요"> </p>
        <p>Password:<input type="text" name="password" placeholder="비밀번호를 생성하세요"></p>
        <p>Phone:<input type="text" name="phone" placeholder="연락처를 입력하세요"></p>
        <p>trainer:<input type="text" name="trainer" placeholder="선생님을 입력하세요"></p>
        <p><input type="submit" value="register"></p>
    </form>
</body>
</html>

