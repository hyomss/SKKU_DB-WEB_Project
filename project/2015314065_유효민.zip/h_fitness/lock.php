<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include('index.php');

session_start();

$user_check=$_SESSION['login_user'];
$ses_sql=mysql_query("select username from ING_Login where username='$user_check' ");

$row=mysql_fetch_array($ses_sql);
$login_session=$row['name'];

if(!isset($login_session))
{
header("Location: login.php");
}
?>
