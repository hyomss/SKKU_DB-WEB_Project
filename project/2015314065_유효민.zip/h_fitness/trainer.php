<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

    define("DB_HOST","localhost");
    define("DB_NAME","h_fitness");
    define("DB_USER","root");
    define("DB_PASSWORD","0406");  
    
    $connection = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    
    if($connection -> connect_error){
        trigger_error("Database connection failed: " . $connection->connect_error, E_USER_ERROR);
    }
  
 
    
    $sql = "select name, phone, gender, year,  rate from trainer;";
    
    $result = $connection -> query($sql);
    function Console_log($result){
    echo "<script>console.log( 'PHP_Console: " . $result . "' );</script>";
}

$testVal = "테스트 데이터";
Console_log($testVal);
    
    if($result === false){
        trigger_error("Sql error, verify sql", E_USER_ERROR);
    }
?>
<DOCTYPE html>
    in trainer
        <table id="Confirms" border ="2" style="length:900px;width:450px;">
                  <thead>
                    <tr style= "background-color: #A4A4A4;">
                      <td>Name</td>
                      <td>Contact</td>
                      <td>Gender</td>
                      <td>WorkingYear</td>
                      <td>Recommended</td>
                      
                    </tr>
                  </thead>
                <tbody>
                    <?php 
                      while(($row = $result->fetch_assoc())){
                        echo
                        "<tr>
                          <td>{$row['name']}</td>
                          <td>0{$row['phone']}</td> <!--db data잘못넣어서 0 추가......시간나면 삭제 재추가-->
                          <td>{$row['gender']}</td>
                          <td>{$row['year']}</td>
                          <td>{$row['rate']} likes</td>
                        </tr>\n"; 
                      } 
                    ?>
                </tbody>
            </table>
</html>


