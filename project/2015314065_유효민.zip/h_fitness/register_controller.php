<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

    define("DB_HOST","localhost");
    define("DB_NAME","h_fitness");
    define("DB_USER","root");
    define("DB_PASSWORD","0406");  
    
    $connection = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    
    if($connection -> connect_error){
        trigger_error("Database connection failed: " . $connection->connect_error, E_USER_ERROR);
    }
 
$sql = "insert into member(name, m_id, password, phone, trainer) values('{$_POST['name']}','{$_POST['m_id']}','{$_POST['password']}','{$_POST['phone']}', '{$_POST['trainer']}');";
$result = mysqli_query($connection,$sql);

function Console_log($result){
    echo "<script>console.log( 'PHP_Console: " . $result . "' );</script>";
}
if($result === false){
    trigger_error("Sql error, verify sql", E_USER_ERROR);
}
$testVal = "테스트 데이터";
Console_log($testVal);
mysqli_close($connection);
// 처리가 완료되면 성공 메시지 보여주고 이동할 페이지로 이동
echo "<script>alert(\"Register Success!\");</script>";
echo "<script>location.href='index.php'</script>";

echo $sql;
?>

