<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 define("DB_HOST","localhost");
    define("DB_NAME","h_fitness");
    define("DB_USER","root");
    define("DB_PASSWORD","0406");  
    
    $connection = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    
    if($connection -> connect_error){
        trigger_error("Database connection failed: " . $connection->connect_error, E_USER_ERROR);
    }

function Console_log($result){
    echo "<script>console.log( 'PHP_Console: " . $result . "' );</script>";
}
$testVal = "테스트 데이터";
Console_log($testVal);
session_start();

?>
<!DOCTYPE html>
<meta http-equiv="Content-Type" content="text/html" charset="utf-8"> <!--utf-8설정-->
<title>Login Page</title>
<br>
<br>
<body>
<a href="index.php">home</a>
<?php if(!isset($_SESSION['m_id']) || !isset($_SESSION['name'])) { ?>
        <form method="post" action="login_ok.php">
            <p>아이디: <input type="text" name="m_id" /></p>
            <p>비밀번호: <input type="password" name="password" /></p>
            <p><input type="submit" value="로그인" /></p>
        </form>
        <?php } /*else {
            $m_id = $_SESSION['m_id'];
            $name = $_SESSION['name'];
            echo "<p><strong>$name</strong>($m_id)님은 이미 로그인하고 있습니다. ";
            echo "<a href=\"index.php\">[돌아가기]</a> ";
            echo "<a href=\"logout.php\">[로그아웃]</a></p>";
        }*/ ?> 
</body>
</html>