<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
    define("DB_HOST","localhost");
    define("DB_NAME","h_fitness");
    define("DB_USER","root");
    define("DB_PASSWORD","0406");  
    
    $connection = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    
    if($connection -> connect_error){
        trigger_error("Database connection failed: " . $connection->connect_error, E_USER_ERROR);
    }
    
    if ( !isset($_POST['m_id']) || !isset($_POST['password']) ) {
        header("Content-Type: text/html; charset=UTF-8");
        echo "<script>alert('아이디 또는 비밀번호가 빠졌거나 잘못된 접근입니다.');";
        echo "window.location.replace('login.php');</script>";
        exit;
    }
    $m_id = $_POST['m_id'];
    $password = $_POST['password']; // 들어오는거 확인
    $sql="SELECT m_id FROM member WHERE m_id='$m_id' and password='$password';";
    $result = mysqli_query($connection,$sql);
     
    $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
     # $active = $row['active'];

      $count = mysqli_num_rows($result);
     
    if($count == 1){    //$count = 1; 
        /* If success */
        session_start();
        $_SESSION['m_id'] = $m_id;
        // $_SESSION['name'] = $name;
    }
    // else{
    if($count !=1){
        header("Content-Type: text/html; charset=UTF-8");
        echo "<script>alert('아이디 또는 비밀번호가 잘못되었습니다.');";
        echo "window.location.replace('login.php');</script>";
        exit;
    }
    /*
    if($result === false){
        trigger_error("Sql error, verify sql", E_USER_ERROR);
    }*/
    
    // If result matched $myusername and $mypassword, table row must be 1 row
   // if($count==1)  //count가 1이라는 것은 아이디와 패스워드가 일치하는 db가 하나 있음을 의미. {}

?>
<meta http-equiv="refresh" content="0;url=index.php" />

