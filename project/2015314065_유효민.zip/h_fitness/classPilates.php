<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

    define("DB_HOST","localhost");
    define("DB_NAME","h_fitness");
    define("DB_USER","root");
    define("DB_PASSWORD","0406");  
    
    $connection = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    
    if($connection -> connect_error){
        trigger_error("Database connection failed: " . $connection->connect_error, E_USER_ERROR);
    }
  
 
    
    $sql = "select time, name, level from trainer inner join class inner join Pilates on class.type = 'Pilates' and class.trainer = trainer.t_id and class.c_id = Pilates.id";
    
    $result = $connection -> query($sql);
    function Console_log($result){
    echo "<script>console.log( 'PHP_Console: " . $result . "' );</script>";
}

$testVal = "테스트 데이터";
Console_log($testVal);
    
    if($result === false){
        trigger_error("Sql error, verify sql", E_USER_ERROR);
    }  
?>
<DOCTYPE html>
    in pilates
      <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
    <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="index.php">Home</a>
    </div>
  </nav>
    
        <table id="Confirms" border ="2" style="length:900px;width:350px;">
                  <thead>
                    <tr style= "background-color: #A4A4A4;">
                      <td> Class Time</td>
                      <td>Trainer</td>
                      <td>Level</td>
                    </tr>
                  </thead>
                <tbody>
                    <?php 
                      while(($row = $result->fetch_assoc())){
                        echo
                        "<tr>
                          <td>{$row['time']}</td>
                          <td>{$row['name']}</td>
                          <td>{$row['level']}</td>
                        </tr>\n"; 
                      } 
                    ?>
                </tbody>
            </table>
</html>
